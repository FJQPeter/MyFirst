package org.springframework.social.weibo.api;

public enum StatusContentType {
	ALL, ORIGINAL, IMAGE, VIDEO, MUSIC
}
