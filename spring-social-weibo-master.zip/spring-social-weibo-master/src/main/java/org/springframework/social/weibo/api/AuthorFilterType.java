package org.springframework.social.weibo.api;

public enum AuthorFilterType {

	ALL, FRIENDS, OTHERS

}
