package org.springframework.social.weibo.api;

public enum SourceFilterType {

	ALL, FROM_WEIBO, FROM_OTHERS

}
